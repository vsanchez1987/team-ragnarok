using System;
using System.Collections.Generic;
using FightGame;
using FSM;

namespace FSM
{
	public class Action_WalkForwardEnter:FSMAction
	{
		public override void execute(FSMContext c, Object o){
			
		}
	}
}

