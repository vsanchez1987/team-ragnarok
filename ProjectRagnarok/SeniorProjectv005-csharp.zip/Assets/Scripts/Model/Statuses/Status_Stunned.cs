using UnityEngine;
using System.Collections;
using FightGame;

namespace FightGame
{
	public class Status_Stunned : A_Status
	{
		public Status_Stunned ()
		{
		}
	}
}

