using UnityEngine;
using System.Collections;
using FightGame;

namespace FightGame
{
	public abstract class A_Status
	{
		protected float duration;
		protected GameObject animation;
	}
}

