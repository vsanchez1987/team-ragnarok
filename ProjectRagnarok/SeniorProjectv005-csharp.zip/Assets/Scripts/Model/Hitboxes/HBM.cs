using UnityEngine;
using System.Collections;

namespace FightGame
{
	public class HBM
	{
		Vector3 startLoc;
		Vector3 velocity;
		float startTime;
		float endTime;
		float damage;
		float radius;
	}
}
