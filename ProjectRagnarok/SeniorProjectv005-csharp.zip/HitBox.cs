using System.Collections.Generic;
using UnityEngine;

namespace FightGame
{
	public class HitBox : MonoBehaviour
	{
		GameObject parentGOB;
		string name;
		//Vector3 location; 
		Collider collider;
		public HitBox ()
		{
		}
		public void UpdateHitBox()
		{
			;//update location here
		}
	}
}

